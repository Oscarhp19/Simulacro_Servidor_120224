<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Ver Precio vivienda</title>
</head>

<body>
    <h2>Verificación de Edad</h2>
    <form action="cliente.php" method="post">
        <label for="id">Id vivienda:</label>
        <input type="number" id="id" name="id" required>
        <button type="submit">Ver precio</button>
    </form>
</body>

</html>