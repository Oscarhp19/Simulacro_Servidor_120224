<link rel="stylesheet" href="style.css">

<header>
    <form action="" method="post">
        <input type="hidden" name="view" value="vivienda">
        <button class="btn-menu" type="submit" value="Inicio">Inicio</button>
    </form>
    <form action="" method="post">
        <input type="hidden" name="view" value="registrar-vivienda">
        <button class="btn-menu" type="submit" value="registrar-vivienda">Registrar Vivienda</button>
    </form>
</header>